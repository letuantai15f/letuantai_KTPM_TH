package com.example.PerssengerService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerssengerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
